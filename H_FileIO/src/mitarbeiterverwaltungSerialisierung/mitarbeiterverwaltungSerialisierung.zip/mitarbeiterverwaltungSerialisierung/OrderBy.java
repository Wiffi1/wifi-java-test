package mitarbeiterverwaltungSerialisierung;

public enum OrderBy {
    NO_ORDER, NAME, TYPE_EINTRITTSDATUM
}
