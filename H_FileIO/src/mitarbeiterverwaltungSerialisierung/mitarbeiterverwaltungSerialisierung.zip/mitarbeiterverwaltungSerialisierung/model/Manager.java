package mitarbeiterverwaltungSerialisierung.model;

//Manager erhalten jährlich einen Bonus, welcher bei der Gehaltserhöhung (s.u.) um denselben Prozentsatz wie das Gehalt erhöht wird.

import java.time.LocalDate;

public class Manager extends Mitarbeiter {

    private static final long serialVersionUID = 2L;

    // Höhe des Bonus ist Verhandlungssache, deshalb nicht static genommen.
    private double bonus;

    public Manager(String name, LocalDate geburtsdatum, LocalDate eintrittsdatum, double grundgehalt, double bonus) {
        super(name, geburtsdatum, eintrittsdatum, grundgehalt);
        this.bonus = bonus;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" Einstufung: %-10s %-11s %8.2f",
                "Manager", "Bonus:", bonus);
    }
}
