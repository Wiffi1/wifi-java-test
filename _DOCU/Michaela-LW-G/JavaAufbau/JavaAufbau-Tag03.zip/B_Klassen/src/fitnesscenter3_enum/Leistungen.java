package fitnesscenter3_enum;
// Konstanten für die Leistungen, die abgebucht werden können
public enum Leistungen {
    GYMNASTIK, GYMNASTIK_SPEZIAL, FITNESS_2H, FITNESS_TAG, WELLNESS


}
