package stringListe;

import inputHilfe.InputUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class FruchtsalatMixer {
    public static void main(String[] args) {
        List<String> fruchtsalat = new ArrayList<>();

        // ein paar Elemente anfügen
        fruchtsalat.add("Banane");
        fruchtsalat.add("Apfel");
        fruchtsalat.add("Birne");
        fruchtsalat.add("Kiwi");

        for (int i = 0; i < fruchtsalat.size(); i++) {
            System.out.printf("%d. Frucht: %s\n", i + 1, fruchtsalat.get(i));
        }

        System.out.println("Welche Frucht dazugeben?");
        String input = InputUtil.readString();
        // den Index der Zeichenfolge suchen (case sensitive)
        int index = fruchtsalat.indexOf(input);
        if (index < 0) {
            System.out.println("Die Frucht kommt noch nicht vor, füge sie dazu...");
            fruchtsalat.add(0, input);
        } else {
            System.out.printf("%s ist schon drin!\n", input);
        }
        // Iteration mit foreach
        System.out.println("Alle Früchte:");
        for (String frucht : fruchtsalat) {
            System.out.println(frucht);
        }

        System.out.println("Welche Frucht entfernen?");
        input = InputUtil.readString();

        // Iteration (und entfernen) mit Iterator
        Iterator<String> iterator = fruchtsalat.iterator();
        // solange es ein weiteres Element gibt
        while (iterator.hasNext()) {
            // auf das Element positionieren und es holen
            String frucht = iterator.next();
            // wenn Element und Eingabe gleich sind -> entfernen
            if (frucht.equalsIgnoreCase(input)) {
                iterator.remove();
                System.out.printf("%s wurde entfernt\n", frucht);
            } else {
                System.out.printf("%s bleibt drin\n", frucht);
            }
        }

        // sortieren (natürliche Reihenfolge, dh. case sensitive)
        Collections.sort(fruchtsalat);
        // alles anzeigen (mit toString der List-Klasse)
        System.out.println("Alle Früchte sortiert:");
        System.out.println(fruchtsalat/*.toString()*/);

        Collections.sort(fruchtsalat, String.CASE_INSENSITIVE_ORDER);
        // alles anzeigen (mit toString der List-Klasse)
        System.out.println("Alle Früchte sortiert (CASE_INSENSITIVE_ORDER):");
        System.out.println(fruchtsalat/*.toString()*/);

    }
}
