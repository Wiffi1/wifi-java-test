module swingDemos {
    // die Klassen und Interfaces für Swing und AWT importieren
    requires java.desktop;
}