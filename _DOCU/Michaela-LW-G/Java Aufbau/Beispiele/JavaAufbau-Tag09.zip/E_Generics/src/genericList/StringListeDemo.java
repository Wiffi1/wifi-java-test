package genericList;

public class StringListeDemo {
    public static void main(String[] args) {
        // die generische Klasse kann für alle Objekt-Typen verwendet werden
        GenerischeListe<String> namen = new GenerischeListe<>(10);
        namen.hinzufuegen("Max");
        namen.hinzufuegen("Susi");
        namen.hinzufuegen("Moritz");
        namen.hinzufuegen("Karo");

        for (int i = 0; i < namen.getAnzahl(); i++) {
            System.out.printf("Name am Index %d: %s\n", i, namen.elementAnIndex(i) );
        }
        System.out.println();


    }
}
