package lotto;

public class LottoProgramm2 {
    public static void main(String[] args) {
        Lottotipp2 tipp1 = new Lottotipp2('Q');
        // TODO: anzeigen
        Lottotipp2 tipp2 = new Lottotipp2('M');
        // TODO: anzeigen


    }
}
