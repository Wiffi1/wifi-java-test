package formatUndParse;

public class ZahlenFormatDemo {
    public static void main(String[] args) {
        // ohne "Format": mit Wrapperklassen
        double wert = Math.PI;

        System.out.println("Die Zahl PI beträgt " + Double.toString(wert));
        // einfacher zu schreiben:
        System.out.println("Die Zahl PI beträgt " + wert);

        // primitiven Wert in Zeichenfolgen umwandeln
        String strValue = Double.toString(wert);
        System.out.println(strValue);

        // aus String zurückumwandeln
        double wertNeu = Double.parseDouble(strValue);
        System.out.println("Aus String ermittelt: " + wertNeu);

        // Wrapper-Objekt aus der Zeichenfolge erzeugen
        Double dObject = Double.valueOf(strValue);
        // den primitiven Wert aus dem Wrapper-Objekt herausholen
        wertNeu = dObject.doubleValue();
        System.out.println("Aus String ermittelt (über Wrapper-Objekt): " + wertNeu);


        double infinite = Double.POSITIVE_INFINITY;
        System.out.println("Unendlich: " + infinite);

    }
}
