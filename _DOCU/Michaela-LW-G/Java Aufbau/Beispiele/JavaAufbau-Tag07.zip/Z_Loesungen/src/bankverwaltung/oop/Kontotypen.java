package bankverwaltung.oop;

public enum Kontotypen {
    GEHALTSKONTO, SPARKONTO
}
