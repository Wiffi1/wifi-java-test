module swdev2021.samples.I_SimpleEditor {
    requires javafx.controls;
    requires javafx.fxml;

    opens editorFx.programm;
}