package rechteckPackage;

// das Hilfsobjekt für den Konsoleninput bekanntmachen
import java.util.Scanner;

public class RechteckProgramm {

	/*
	 * Mehrzeiliger Kommentar ...
	 * 
	 */
	public static void main(String[] args) {
		// Programm zur Berechnung von Fläche und Umfang eines Rechtecks
		// Variablen für Länge und Breite
		int laenge, breite;

		// Werte vom Benutzer einlesen:
		// Hilfsobjekt erzeugen, das vom Konsole-Inputstream liest
		Scanner input = new Scanner(System.in);

		// die Länge einlesen und in der vorgesehenen Variable eintragen (=Zuweisung)
		System.out.println("Gib bitte die Länge ein:");
		laenge = input.nextInt();

		// die Breite einlesen und in der vorgesehenen Variable eintragen (=Zuweisung)
		System.out.println("Gib bitte die Breite ein:");
		breite = input.nextInt();

		// Berechnung durchführen und den vorgesehenen Variablen zuweisen
		int flaeche = laenge * breite;
		int umfang = 2 * (laenge + breite);
		
		System.out.println("Fläche: " + flaeche);
		System.out.println("Umfang: " + umfang);
		
		// das Input-Objekt schließen
		input.close();
		
	}

}
