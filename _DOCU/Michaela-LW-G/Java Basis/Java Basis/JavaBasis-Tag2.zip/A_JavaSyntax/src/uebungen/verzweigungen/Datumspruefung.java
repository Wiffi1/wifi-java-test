package uebungen.verzweigungen;

public class Datumspruefung {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	// Methode zum ermitteln der Anzahl von Tagen in einem Monat ohne Berücksichtigung
	// von Schaltjahren
	// Input: monat (byte, weil nur werte von 1-12 möglich sind)
	// Output: Anzahl Tage (byte weil nur die Werte von 28-31 möglich sind)
	static byte ermittleAnzahlTage (byte monat) {
		byte anzahl = 0;
		// TODO: je nach Monat die passende Anzahl berechnen
		
		return anzahl;
	}

}
