package uebungen.verzweigungen;

public class Dreiecke {

	public static void main(String[] args) {

		// TODO Variablen für die Seitenlängen deklarieren und vom Benutzer einlesen
		double a, b, c;

		// vorübergehend fixe Werte angeben, damit wir die Variablen lesen dürfen
		a = 3;
		b = 4;
		c = 5;

		// TODO einlesen

		// TODO Boolesche Variablen für rechtwinkelig, gleichseitig,
		// gleichschenkelig und dreieck (ob es überhaupt ein Dreieck ist) deklarieren

		boolean istRechtwinkelig, istGleichschenkelig;

		// TODO: mit einzelnen if-Anweisungen feststellen ob die Eigenschaften zutreffen
		// TODO: rechtwinkelig
		if (a * a + b * b == c * c) { // TODO: 2 x drehen
			istRechtwinkelig = true;
		} else {
			istRechtwinkelig = false;
		}

		// TODO: gleichseitig

		// TODO: gleichschenkelig
		if (a == b) { // TODO: 2 x drehen
			istGleichschenkelig = true;
		} else {
			istGleichschenkelig = false;
		}

		// TODO: dreieck

		// TODO: (vorübergehend) die ermittelten Eigenschaften anzeigen

		// TODO: anzeigen, in welche der Kategorien das Dreieck fällt:
		// rechtwinkelig, gleichseitig, gleichschenkelig,
		// rechtwinkelig-gleichschenkelig, allgemein, kein Dreieck

		// ...
		// rechtwinkelig-gleichschenkelig?
		if (istRechtwinkelig == true && istGleichschenkelig == true) {
			System.out.println("Es ist ein rechtwinkelig-gleichschenkeliges Dreieck");
		}
		// ... TODO: weitere Bedingungen, mit else-if
	}

}
