package verzweigungen;

import java.util.Scanner;

public class Schulnoten2_Switch {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Welche Note (1-5)");

		byte note = input.nextByte();
		// Variable für das Ergebnis
		String notenText;

		/*if (note == 1) {
			notenText = "Sehr gut";
		} else if (note == 2) {
			notenText = "Gut";
		} else if (note == 3) {
			notenText = "Befriedigend";
		} else if (note == 4) {
			notenText = "Genügend";
		} else if (note == 5) {
			notenText = "Nicht genügend";
		} else {
			notenText = "n.v.";
			System.err.println("Ungültige Note!");
		}*/
		// neu mit switch
		switch (note) {
		case 1:
			notenText = "Sehr gut";
			break;
		case 2:
			notenText = "Gut";
			break;
		case 3:
			notenText = "Befriedigend";
			break;
		case 4:
			notenText = "Genügend";
			break;
		case 5:
			notenText = "Nicht genügend";
			break;
		default:
			notenText = "n.v.";
			System.err.println("Ungültige Note!");
			break;
		}
		
		// statt String-Verkettung
		// System.out.println("Die Note " + note + " entspricht '" + notenText + "'");

		// formatierte Ausgabe mit Platzhaltern
		// %d ... ganze Zahl
		// %s ... Zeichenfolge
		// %f ... Fließkommazahl
		System.out.printf("Die Note %d entspricht '%s'\n", note, notenText);
		input.close();
	}

}
