package methoden;

import java.util.Scanner;

public class SchulnotenMethode {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Welche Note für Deutsch?");
		byte deutsch = input.nextByte();
		// unsere Methode aufrufen und die deutsch-Note übergeben
		// das Ergebnis merken wir uns einer Variable
		String textNoteDeutsch = ermittleNotentext(deutsch);
		
		System.out.println("Welche Note für Mathe?");
		byte mathe = input.nextByte();
		// wieder die Methode aufrufen
		String textNoteMathe = ermittleNotentext(mathe);
		
		System.out.printf("Note Deutsch: '%s', Note Mathe: '%s'\n", textNoteDeutsch, textNoteMathe);
		
		input.close();

	}

	// Methode zum ermitteln des Textes zu einer Schulnote
	// (static, damit wir für den Aufruf kein Objekt benötigen)
	static String ermittleNotentext(byte note){
		
		// Variable für das Ergebnis
		String notenText;
		// Ergebnis ermitteln
		switch (note) {
		case 1:
			notenText = "Sehr gut";
			break;
		case 2:
			notenText = "Gut";
			break;
		case 3:
			notenText = "Befriedigend";
			break;
		case 4:
			notenText = "Genügend";
			break;
		case 5:
			notenText = "Nicht genügend";
			break;
		default:
			notenText = "n.v.";
			System.err.println("Ungültige Note!");
			break;
		}
		// Ergebnis zurückliefern
		return notenText;
	}
}
