package schleifen;

import java.util.Scanner;

public class Monatseingabe {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		byte monat;

		do {
			System.out.println("In welchem Monat bist du geboren (1-12)?");
			monat = input.nextByte();
			// wenn es ungültig ist -> Fehler anzeigen
			if (monat < 1 || monat > 12) {
				System.err.println("Ungültiges Monat!");
			}
		} while (monat < 1 || monat > 12);

		System.out.println("Eingegebenes Monat: " + monat);

		input.close();

	}

}
