package uebungen;

import java.util.Scanner;

public class Uhrzeit1Programm {

	public static void main(String[] args) {
		int stunde, minute, sekunde;

		// Werte vom Benutzer einlesen:
		// Hilfsobjekt erzeugen, das vom Konsole-Inputstream liest
		Scanner input = new Scanner(System.in);

		// die Stunde einlesen 
		System.out.println("Gib bitte die Stunde ein:");
		stunde = input.nextInt();
		// die Minute einlesen 
		System.out.println("Gib bitte die Minute ein:");
		minute = input.nextInt();
		// die Sekunde einlesen 
		System.out.println("Gib bitte die Sekunde ein:");
		sekunde = input.nextInt();

		int gesamtSekunden= stunde * 3600 + minute * 60 + sekunde;
		
		System.out.println("Sekunden gesamt: " + gesamtSekunden);
		input.close();
	}

}
