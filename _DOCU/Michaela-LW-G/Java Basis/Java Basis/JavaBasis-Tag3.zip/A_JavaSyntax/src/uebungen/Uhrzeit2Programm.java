package uebungen;

import java.util.Scanner;

public class Uhrzeit2Programm {

	public static void main(String[] args) {

		// Werte vom Benutzer einlesen:
		// Hilfsobjekt erzeugen, das vom Konsole-Inputstream liest
		Scanner input = new Scanner(System.in);

		// die Sekunde einlesen
		System.out.println("Gib bitte die Sekunde ein:");
		int sekunden = input.nextInt();
		int stunde, minute, sekunde;
		stunde = sekunden / 3600;
		minute = sekunden / 60 % 60;
		sekunde = sekunden % 60;

		System.out.println(stunde + " Stunden");
		System.out.println(minute + " Minuten");
		System.out.println(sekunde + " Sekunden");
		
		input.close();

	}

}
