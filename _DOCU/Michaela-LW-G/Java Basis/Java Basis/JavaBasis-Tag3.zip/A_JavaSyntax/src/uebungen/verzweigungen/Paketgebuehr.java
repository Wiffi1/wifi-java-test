package uebungen.verzweigungen;

import java.util.Scanner;

/**
 * 
 * Erstelle ein Programm zur Berechnung der Paketgebühr für die
 * Inlandbeförderung. Die Paketgebühr setzt sich folgendermaßen zusammen: Für
 * Pakete unter 5 kg wird eine Gebühr von € 5.- berechnet, bis 10 kg € 8.-, bis
 * 15 kg € 11.- und bis 20 kg € 13.-. Bei Behandlung als Sperrgut erhöht sich
 * dieser Preis um 50%. Die Eilgebühr beträgt € 2.- pro Paket. Das Programm soll
 * das Gewicht des Pakets und eine Kennung für Sperrgut sowie eine Kennung für
 * Eilsendung einlesen und die entsprechende Gebühr ausgeben.
 *
 */
public class Paketgebuehr {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); 

		// Variablen für den Benutzer-Input (...) definieren
		double gewicht;
		char eilsendung, sperrgut;

		System.out.println("Wie schwer ist das Paket?");
		// Werte vom Benutzer einlesen
		gewicht= input.nextDouble();
		
		System.out.println("Ist es Sperrgut (j/n)?");
		sperrgut = input.next().charAt(0);
		System.out.println("Soll es als Eilsenudung zugestellt werden (j/n)?");
		eilsendung = input.next().charAt(0);
		
		System.out.printf("%f, %c, %c", gewicht, eilsendung, sperrgut);

		// TODO Grundpreis berechnen:

		// ...

		input.close();
	}

}
