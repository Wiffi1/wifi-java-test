package uebungen.verzweigungen;

public class Gehaltsauszahlung {

	public static void main(String[] args) {
		

	}

}
