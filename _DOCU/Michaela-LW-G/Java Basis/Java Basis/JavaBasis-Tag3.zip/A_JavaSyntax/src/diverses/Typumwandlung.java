package diverses;

import java.util.Scanner;

public class Typumwandlung {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		byte byte1;
		int zahl1;
		float float1;

		System.out.println("Ganzzahl:");
		byte1 = input.nextByte();

		// Umwandlung nach int (implizit)
		zahl1 = byte1;

		System.out.println("Deine Ganzzahl ist " + zahl1);

		// Umwandlung nach float (implizit)
		float1 = byte1;
		System.out.println("Deine Floatzahl ist " + float1);

		// explizite Umwandlungen (mit Type cast)
		// int nach byte
		byte1 = (byte) zahl1;
		System.out.printf("%d gecastet nach byte: %d\n", zahl1, byte1);

		zahl1 = 1234567898;
		// Umwandlung nach float (implizit, aber nicht exakt)
		float1 = zahl1;
		System.out.println("Deine Floatzahl (aus int) ist " + float1);

		// explizite Umwandlungen (mit Type cast)
		// int nach byte
		byte1 = (byte) zahl1;
		System.out.printf("%d gecastet nach byte: %d\n", zahl1, byte1);
		
		// float nach int
		zahl1 = (int)float1;
		System.out.printf("%f gecastet nach int: %d\n", float1, zahl1);
		

		input.close();

	}

}
