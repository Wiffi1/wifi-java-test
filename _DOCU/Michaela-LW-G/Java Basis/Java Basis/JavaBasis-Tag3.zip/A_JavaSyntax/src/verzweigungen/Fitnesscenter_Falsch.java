package verzweigungen;

import java.util.Scanner;

/*
 * Ein Fitnesscenter bietet Jahreskarten zu folgenden Konditionen an: 

Der Standardpreis beträgt €500, Studenten zahlen  €400. Zusätzlich gibt es für alle, 
die schon über 3 Jahre Kunden im Fitnesscenter sind, einen Stammkundenbonus von €50. 

Der Benutzer muss eingeben, ob der Kunde Student ist und wie lange er bereits Kunde 
ist. Anschließend berechnet das Programm den Preis für die Jahreskarte des Kunden.
 */
public class Fitnesscenter_Falsch {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Ist der Kunde Student (j/n)?");
		// charAt liefert das n. Zeichen aus einer Zeichnfolge, wobei der Index bei 0
		// beginnt
		// -> charAt(0) liefert also das 1. Zeichen
		String istStudent = input.nextLine();

		System.out.println("Wieviele Jahre ist der Kunde Mitglied?");
		int jahre = input.nextInt();

		// zuerst den passenden Grundpreis festlegen
		double preis;
		// wenn der Kunde Student ist -> 400 €
		// funktioniert für String nicht!!!
		if (istStudent == "ja") {
			preis = 400.0;
			//System.out.println("Ist Student!!!");
		} else { // sonst -> 500 €
			preis = 500.0;
		}

		// das wäre syntaktisch auch möglich
//		if (istStudent == 'j')
//			preis = 400.0;
//		else // sonst -> 500 €
//			preis = 500.0;

		// jetzt ggf. Stammkundenbonus abziehen
		if (jahre > 3) {
			//preis = preis - 50;
			// Kurzschreibweise für Subtraktion
			preis -= 50;
			
		}
		
		System.out.println("Der Preis beträgt € " + preis );
		
		input.close();
	}

}
