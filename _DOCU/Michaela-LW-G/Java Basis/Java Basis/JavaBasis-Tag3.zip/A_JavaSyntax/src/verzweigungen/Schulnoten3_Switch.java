package verzweigungen;

import java.util.Scanner;

public class Schulnoten3_Switch {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Welche Note (1-5)");

		byte note = input.nextByte();
		// Variable für das Ergebnis
		String folgeKurs;

		/*switch (note) {
		case 1:
		case 2:
			folgeKurs = "Nerd-Kurs";
			break;
		case 4:
		case 5:
			folgeKurs = "Förderkurs";
			break;
		default:
			folgeKurs = "n.v";
			break;
		}*/
		
		switch (note) {
		case 1, 2:
			folgeKurs = "Nerd-Kurs";
			break;
		case 4, 5:
			folgeKurs = "Förderkurs";
			break;
		default:
			folgeKurs = "n.v";
			break;
		}
		
		
		// statt String-Verkettung
		// System.out.println("Die Note " + note + " entspricht '" + notenText + "'");

		// formatierte Ausgabe mit Platzhaltern
		// %d ... ganze Zahl
		// %s ... Zeichenfolge
		// %f ... Fließkommazahl
		System.out.printf("Für Note %d gibt es folgenden Kurs: '%s'.\n", note, folgeKurs);
		input.close();
	}

}
