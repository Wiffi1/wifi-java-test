package verzweigungen;

import java.util.Scanner;

/*
 * Erstelle ein Programm, welches für zwei Eingabezahlen und einen Operator 
 * eine der 4 Grundrechnungsarten durchführt und das Ergebnis ausgibt.
 * Eingabe: Zahl1, Zahl2, Operator ( + , – , * , / )
 * Ausgabe: je nach Operator, Eingabezahlen addiert, subtrahiert, multipliziert oder dividiert.
 */
public class Taschenrechner {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); 
		
		System.out.println("Zahl 1:");
		double zahl1 = input.nextDouble();
		
		System.out.println("Zahl 2:");
		double zahl2 = input.nextDouble();
		
		System.out.println("Operator (+ - / *):");
		char operator = input.next().charAt(0); 

		double ergebnis;
		switch (operator) {
		case '+':
			ergebnis = zahl1 + zahl2;
			break;
		case '-':
			ergebnis = zahl1 - zahl2;
			break;
		case '*':
			ergebnis = zahl1 * zahl2;
			break;
		case '/':
			ergebnis = zahl1 / zahl2;
			break;

		default:
			System.err.println("Ungültiger Operator");
			ergebnis = 0;
			break;
		}
		System.out.println("Ergebnis: " + zahl1 + operator + zahl2 + " == " + ergebnis);
		
		input.close();
	}

}
