package verzweigungen;

import java.util.Scanner;

public class Gehaltsauszahlung {

	/*
	 * Erstellen Sie ein Programm zur Gehaltsauszahlung. Eingegeben werden Gehalt
	 * und Anzahl der Kinder. Bei 1 Kind Zulage = 125, bei 2 Kindern je 110, bei
	 * mehr als 2: je Kind 100. Ab dem 6. Kind wird keine weitere Zulage gewährt.
	 * Eingabe: Gehalt und Kinderzahl Ausgabe: gesamter Betrag und aufgeschlüsselt
	 * in Gehalt und Zulage.
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		// Einlesen der Werten vom Benutzer
		System.out.println("Bitte gib die Höhe des Gehalts ein:");
		double gehalt = input.nextDouble();

		System.out.println("Bitte gib die Kinderanzahl ein:");
		byte kinder = input.nextByte();

		double zulage, gesamtgehalt;

		if (kinder <= 0) {
			System.out.println("Ungültige Anzahl");
			zulage = 0;
		} else if (kinder == 1) {
			zulage = 125;
		} else if (kinder == 2) {
			zulage = 2 * 110;
		} else if (kinder >= 3 && kinder <= 5) {
			zulage = kinder * 100;
		} else {
			zulage = 5 * 100;
		}

		gesamtgehalt = gehalt + zulage;
		System.out.print("Das Gesamtgehalt beträgt " + gesamtgehalt + "€, ");
		System.out.println(gehalt + "€ Gehalt und " + zulage + "€ Zulage.");

		input.close();
	}

}
