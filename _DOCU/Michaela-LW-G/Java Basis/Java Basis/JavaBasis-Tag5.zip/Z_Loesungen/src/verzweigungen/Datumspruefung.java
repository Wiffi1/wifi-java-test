package verzweigungen;

import java.util.Scanner;

public class Datumspruefung {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Tag:");
		byte tag = input.nextByte();

		System.out.println("Monat:");
		byte monat = input.nextByte();

		System.out.println("Jahr:");
		int jahr = input.nextInt();

		boolean istGueltig = true;

		if (jahr < 1600) {
			System.err.println(" ... Ungültiges Jahr");
			istGueltig = false;
		} else if (monat < 1 || monat > 12) {
			System.err.println(" ... Ungültiges Monat");
			istGueltig = false;
		} else {
			byte monatsTage = 0;
			switch (monat) {
			case 1, 3, 5, 7, 8, 10, 12:
				monatsTage = 31;
				break;
			case 4, 6, 9, 11:
				monatsTage = 30;
				break;
			case 2:
				if (jahr % 4 == 0 && jahr % 100 != 0 || jahr % 400 == 0) {
					monatsTage = 29;
				} else {
					monatsTage = 28;
				}
				break;
			}
			if (tag < 1 || tag > monatsTage) {
				System.err.println(" ... Ungültiger Tag, monatsTage=" + monatsTage);
				istGueltig = false;
			}

		}
		if (istGueltig) {
			System.out.println("Das Datum ist gültig");
		} else {
			System.out.println("Das ist kein gültiges Datum");
		}
		input.close();
	}

}
