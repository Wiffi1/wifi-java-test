package verzweigungen;

import java.util.Scanner;

/*
 * Erstelle ein Programm zur Feststellung der Art eines Dreiecks.
 * Eingabe: drei Seitenlängen
 * Ausgabe: je nach Art, einer der folgenden Werte: 
 * rechtwinkelig, gleichseitig, gleichschenkelig, rechtwinkelig-gleichschenkelig, allgemein, kein Dreieck
 * 
 * Hinweise:
 * bei rechtwinkeligen Dreiecken gilt Pythagoras (a * a + b * b = c * c).
 * bei gleichseitigen Dreiecken sind alle Seiten gleich lang
 * bei gleichschenkeligen Dreiecken sind 2 Seiten gleich lang
 * für allgemeine Dreiecke gilt, dass jede Seite jeweils kleiner sein muss als die 
 * Summe der beiden anderen Seiten (Die Seitenlängen 6, 3, und 2 ergeben kein Dreieck)
 */
public class Dreiecke2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		// Variablen für die Seitenlängen deklarieren und vom Benutzer einlesen
		double a, b, c;

//		// vorübergehend fixe Werte angeben, damit wir die Variablen lesen dürfen
//		a = 3;
//		b = 4;
//		c = 5;

		// Seitenlängen einlesen
		System.out.println("Gib bitte die Seitenlängen des Dreiecks ein:");
		System.out.println("Seite A: ");
		a = input.nextDouble();
		System.out.println("Seite B: ");
		b = input.nextDouble();
		System.out.println("Seite C: ");
		c = input.nextDouble();

		// Boolesche Variablen für die Eigenschaften rechtwinkelig, gleichseitig,
		// gleichschenkelig und dreieck (ob es überhaupt ein Dreieck ist) deklarieren
		boolean istRechtwinkelig = false, istGleichschenkelig = false, istGleichseitig = false, istDreieck = false;

		// mit einzelnen if-Anweisungen feststellen ob die Eigenschaften zutreffen
		// rechtwinkelig (mit Pythagoras)
		if (a * a + b * b == c * c || b * b + c * c == a * a || c * c + a * a == b * b) {
			istRechtwinkelig = true;
		}

		// gleichseitig
		if (a == b && b == c) {
			istGleichseitig = true;
		}

		// gleichschenkelig
		if (a == b || b == c || c == a) {
			istGleichschenkelig = true;
		}

		// dreieck
		if (a < b + c && b < c + a && c < a + b) {
			istDreieck = true;
		}

		// (vorübergehend) die ermittelten Eigenschaften anzeigen
		System.out.println(" ... istGleichseitig: " + istGleichseitig);
		System.out.println(" ... istGleichschenkelig: " + istGleichschenkelig);
		System.out.println(" ... istRechtwinkelig: " + istRechtwinkelig);
		System.out.println(" ... istDreieck: " + istDreieck);

		// anzeigen, in welche der Kategorien das Dreieck fällt:
		// rechtwinkelig, gleichseitig, gleichschenkelig,
		// rechtwinkelig-gleichschenkelig, allgemein, kein Dreieck

		// wenn es ein Dreieck ist, auch die anderen Eigenschaften prüfen
		if (istDreieck) {
			// gleichseitig ?
			if (istGleichseitig ) {
				System.out.println("Es ist ein gleichseitiges Dreieck");
			}
			// rechtwinkelig-gleichschenkelig
			else if (istRechtwinkelig  && istGleichschenkelig ) {
				System.out.println("Es ist ein rechtwinkelig-gleichschenkeliges Dreieck");
			}
			// nur rechtwinkelig
			else if (istRechtwinkelig ) {
				System.out.println("Es ist ein rechtwinkeliges Dreieck");
			}
			// nur gleichschenkelig
			else if (istGleichschenkelig ) {
				System.out.println("Es ist ein gleichschenkeliges Dreieck");
			}
			// sonst: allgemeines Dreieck
			else {
				System.out.println("Es ist ein allgemeines Dreieck");
			}
		} else {
			System.out.println("Es ist kein Dreieck");
		}

		input.close();
	}

}
