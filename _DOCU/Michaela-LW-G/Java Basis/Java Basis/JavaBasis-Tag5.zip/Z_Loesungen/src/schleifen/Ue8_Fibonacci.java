package schleifen;
/*
 * Von Leonardo von Pisa, genannt Fibonacci, stammt die Formel, nach der sich Kaninchenpaare vermehren: 
 * Jedes Kaninchenpaar braucht einen Monat um geschlechtsreif zu werden; dann produziert es jeden Monat 
 * ein neues Paar. Am Beginn des ersten Monats gibt es ein Kaninchenpaar, einen Monat später noch immer 
 * eines, im dritten Monat sind es zwei, im vierten drei, im fünften bereits fünf, dann 8, dann 13 usw. 
 * Diese Zahlenfolge (1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89,......) heißt Fibonacci-Folge; 
 * sie beginnt mit 1 und 1; jedes weitere Glied berechnet sich als die Summe der beiden unmittelbaren 
 * Vorgänger. 
 * Schreibe ein Programm, das zwei Zahlen einliest und alle Fibonacci-Zahlen zwischen diesen beiden 
 * Zahlen ausgibt.
*/

import java.util.Scanner;

public class Ue8_Fibonacci {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		int ug, og;
		System.out.print("Untergrenze: ");
		ug = input.nextInt();
		System.out.print("Obergrenze: ");
		og = input.nextInt();
		// 2 Zahlen für die Reihe deklarieren
		int fib1 = 1, fib2 = 1;
		// wenn die Ausgabe am Anfang beginnen soll, auch die erste Zahl der Reihe anzeigen
		if (fib1 >= ug)
			System.out.print(fib1 + " ");

		// jetzt alle Fibnoacci-Zahlen bis zur Obergrenze berechnen 
		while (fib2 <= og) {
			// die Zahl ausgeben, wenn sie im gewünschten Bereich liegt
			if (fib2 >= ug)
				System.out.print(fib2 + " ");
			int tmp = fib1;
			fib1 = fib2;
			fib2 += tmp;
		}
		System.out.println();
		input.close();
	}

}
