package schleifen;

import java.util.Scanner;

/*
 * Schreibe ein Programm, das eine Zahl einliest und berechnet, 
 * ob die eingelesene Zahl eine Primzahl ist oder nicht. 
 * Eine Primzahl ist eine nur durch 1 oder sich selbst teilbare Zahl.
*/
public class Ue3a_Primzahl {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		// Zahl einlesen
		System.out.print("Welche Zahl? ");
		int zahl = input.nextInt();

		// annehmen dass es eine Primzahl ist
		boolean istPrim = true;
		// für alle Zahlen von 2 bis zur Hälfte der Zahl
		for (int i = 2; i <= zahl / 2; i++) {
			// wenn dieses i ein ganzzahliger Teiler von Zahl ist
			if (zahl % i == 0) {
				// ist es keine Primzahl
				istPrim = false;
				// nicht mehr weiterprüfen
				break;
			}

		}

		// Ergebnis anzeigen
		if (istPrim) {
			System.out.println(zahl + " ist eine Primzahl");
		} else {
			System.out.println(zahl + " ist keine Primzahl");
		}

		input.close();
	}

}
