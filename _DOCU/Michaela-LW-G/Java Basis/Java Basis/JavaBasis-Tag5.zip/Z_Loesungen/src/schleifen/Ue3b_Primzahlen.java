package schleifen;

import java.util.Scanner;

/*
 * Schreibe ein Programm zur Berechnung aller Primzahlen zwischen zwei einzugebenden Grenzen.
 * Eingabe: Unter- und Obergrenze (z.B.: 10 und 20)
 * Ausgabe: Primzahlen in diesem Bereich (z.B.: 11, 13, 17, 19)
*/
public class Ue3b_Primzahlen {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		// Grenzen einlesen
		int ug, og;
		System.out.print("Untergrenze: ");
		ug = input.nextInt();
		System.out.print("Obergrenze: ");
		og = input.nextInt();

		for (int zahl = ug; zahl <= og; zahl++) {
			// annehmen dass es eine Primzahl ist
			boolean istPrim = true;
			// für alle Zahlen von 2 bis zur Hälfte der Zahl
			for (int i = 2; i <= zahl / 2; i++) {
				// wenn dieses i ein ganzzahliger Teiler von Zahl ist
				if (zahl % i == 0) {
					// ist es keine Primzahl
					istPrim = false;
					// nicht mehr weiterprüfen
					break;
				}

			}

			if (istPrim) {
				System.out.print(zahl + " ");
			}
		}
		System.out.println();
		
		input.close();

	}

}
