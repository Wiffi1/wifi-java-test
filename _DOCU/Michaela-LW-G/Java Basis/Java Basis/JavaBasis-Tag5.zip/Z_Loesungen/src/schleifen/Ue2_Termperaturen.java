package schleifen;

import java.util.Scanner;

/*
 * Schreibe ein Programm, das Temperaturwerte einliest (beliebig viele; Ende der Eingabe durch 1000) 
 * und dann das Minimum, das Maximum und den Durchschnitt aller eingegebenen Temperaturwerte berechnet.
 */
public class Ue2_Termperaturen {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double min = 1000, max = -1000, sum = 0, count = 0;
		double zahl;
		System.out.println("Temperaturen eingeben, Ende durch 1000");
		
		// Zahlen einlesen
		do {
			zahl = input.nextInt();
			if (zahl != 1000) {
				count++;
				sum += zahl;
				if (zahl < min)
					min = zahl;
				if (zahl > max)
					max = zahl;
			}
			
		} while (zahl != 1000);
		// Ergebnis anzeigen
		if (count > 0) {
			System.out.println("Minimum: " + min);
			System.out.println("Maximum: " + max);
			System.out.println("Durchschnitt: " + (sum / count));
		} else {
			System.out.println("Kein Sample vorhanden");
		}
		input.close();
	}

}
