package schleifen;
/*
 * Schreibe ein Programm zur Berechnung der Summe und des Durchschnitts einzugebender Zahlen: 
 * Eingabe: Zahlenfolge (Ende der Folge durch Eingabe: 0) 
 * Ausgabe: Summe und Durchschnittswert.
 */

import java.util.Scanner;

public class Ue6_SummeDurchschnitt {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double sum = 0, count = 0;
		double zahl;
		
		System.out.println("Zahlen eingeben, Ende durch 0");
		// Zahlen einlesen
		do {
			zahl = input.nextInt();
			if (zahl != 0) {
				count++;
				sum += zahl;
			}
			
		} while (zahl != 0);
		
		// Ergebnis anzeigen
		if (count > 0) {
			System.out.println("Summe: " + sum);
			System.out.println("Durchschnitt: " + (sum / count));
		} else {
			System.out.println("Kein Sample vorhanden");
		}
		input.close();
	}

}
