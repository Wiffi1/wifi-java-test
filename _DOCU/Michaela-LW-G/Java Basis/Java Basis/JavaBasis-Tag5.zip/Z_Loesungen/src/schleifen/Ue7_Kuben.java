package schleifen;
/*
 * Schreibe ein Programm, das alle dreistelligen Zahlen dahingehend überprüft, 
 * ob sie gleich sind der Summe der Kuben ihrer Ziffern (z.B.: 153=1*1*1+5*5*5+3*3*3)
*/

public class Ue7_Kuben {

	public static void main(String[] args) {


		// für alle 3-stelligen Zahlen
		for (int zahl = 100; zahl <= 999; zahl++) {
			// ziffern berechnen:
			int ziff1 = zahl / 100 % 10, ziff2 = zahl / 10 % 10, ziff3 = zahl % 10;
			// kubensumme berechnen
			int kubenSumme = ziff1 * ziff1 * ziff1 + ziff2 * ziff2 * ziff2 + ziff3 * ziff3 * ziff3;
			if (kubenSumme == zahl) {
				System.out.printf(
						"Die Summe der Kuben der Ziffern von %d ist gleich der Zahl (%d %d %d)\n", zahl,
						ziff1, ziff2, ziff3);
			}
		}
	}

}
