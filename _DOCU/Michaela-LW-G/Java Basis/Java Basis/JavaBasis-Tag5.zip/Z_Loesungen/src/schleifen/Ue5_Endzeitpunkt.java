package schleifen;
/*
 * Schreibe ein Programm, das einen Zeitpunkt (Stunde, Minuten) und beliebig  
 * viele Zeiträume (nur in Minuten) einliest (Ende durch Eingabe von 0 Minuten); 
 * die Minuten sollen zum Zeitpunkt addiert werden und der Endzeitpunkt 
 * soll ausgegeben werden.
*/

import java.util.Scanner;

public class Ue5_Endzeitpunkt {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		// Startzeit einlesen
		int stunde, minute;
		System.out.print("Stunde: ");
		stunde = input.nextInt();
		System.out.print("Minute: ");
		minute = input.nextInt();

		// Startzeit in Minuten umrechnen
		int zeitpunkt = stunde * 60 + minute;
		System.out.println("Zeiträume (in Minuten eingeben, Ende mit 0)");
		// Zeiträume dazuzählen
		do {
			minute = input.nextInt();
			zeitpunkt += minute;
		} while (minute > 0);

		// Strunde und Minute aus dem Zeitpunkt berechnen
		stunde = zeitpunkt / 60;
		minute = zeitpunkt % 60;
		int tage = stunde / 24;
		if (tage > 0) {
			stunde %= 24;
		}
		if (tage == 0) {
			System.out.printf("Der Endzeitpunkt ist %02d:%02d\n", stunde, minute);
		} else {
			System.out.printf("Der Endzeitpunkt ist %02d:%02d, %d Tage später\n", stunde, minute, tage);
		}
		input.close();
	}

}
