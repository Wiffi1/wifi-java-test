package schleifen;

import java.util.Scanner;

/*
 * Schreibe ein Programm, das ein Anfangskapital, einen Zinssatz und eine Veranlagungsdauer einliest 
 * und am Ende eines jeden Jahres die Höhe der Einlage und die gutgeschriebenen Zinsen ausgibt.
 */
public class Ue4_Zinsberechnung {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		int jahre;
		double kapital, zinsfaktor;
		// ausgangswerte einlesen
		System.out.print("Anfangskapital: ");
		kapital = input.nextDouble();
		System.out.print("Zinssatz: ");
		// zinsfaktor: zinssatz / 100
		zinsfaktor = input.nextDouble() / 100.0;
		System.out.print("Dauer in Jahren: ");
		jahre = input.nextInt();
		// Schleife für jedes Jahr
		for (int i = 1; i <= jahre; i++) {
			double zinsen = kapital * zinsfaktor;
			// Zuwachs berechnen
			kapital += zinsen;
			// Zwischenergebnis ausgeben
			System.out.printf(
					"Nach dem %d. Jahr werden %.2f EUR Zinsen gutgeschrieben, das Kapital beträgt %.2f\n",
					i,zinsen, kapital);
		}

		input.close();
	}

}
