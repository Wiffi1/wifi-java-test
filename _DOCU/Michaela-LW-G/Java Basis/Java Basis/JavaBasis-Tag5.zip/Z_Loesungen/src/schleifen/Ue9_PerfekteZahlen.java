package schleifen;
/*
 * Eine Zahl heißt perfekt, wenn sie gleich ist der Summe aller ihrer Teiler (außer sich selbst); 
 * z.B. 28 = 1 + 2 + 4 + 7 + 14. 
 * Schreibe ein Programm, das eine Zahl einliest und alle perfekten Zahlen <= dieser Obergrenze ausgibt.
*/

import java.util.Scanner;

public class Ue9_PerfekteZahlen {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		long og;
		System.out.print("Obergrenze: ");
		og = input.nextLong();
		// für alle Zahlen bis zur Obergrenze
		for (long zahl = 2; zahl <= og; zahl++) {
			int teilerSumme = 0;
			for (long teiler = zahl / 2; teiler >= 1; teiler--) {
				if (zahl % teiler == 0) {
					teilerSumme += teiler;
				}
			}
			if (teilerSumme == zahl) {
				System.out.println(zahl + " ist eine perfekte Zahl");
			}
		}
		input.close();
	}

}
