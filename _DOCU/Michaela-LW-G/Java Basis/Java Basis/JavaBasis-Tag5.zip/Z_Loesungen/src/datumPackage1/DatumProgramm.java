package datumPackage1;

import java.util.Scanner;

public class DatumProgramm {

	public static void main(String[] args) {
		byte tag, monat;
		int jahr;
		
		Scanner input = new Scanner(System.in);
		System.out.print("Tag:");
		tag = input.nextByte();
		System.out.print("Monat:");
		monat = input.nextByte();
		System.out.print("Jahr:");
		jahr = input.nextInt();
		
		if(DatumMethoden.istGueltig(tag, monat, jahr)) {
			System.out.println("Gültiges Datum");
		}else {
			System.out.println("Das Datum ist nicht gültig");
			
		}
		
		input.close();

	}

}
