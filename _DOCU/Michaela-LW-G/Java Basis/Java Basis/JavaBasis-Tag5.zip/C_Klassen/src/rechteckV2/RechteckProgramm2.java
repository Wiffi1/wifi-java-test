package rechteckV2;

public class RechteckProgramm2 {

	public static void main(String[] args) {
		// Unsere Klasse Rechteck ist ein Datentyp, ähnlich den Grunddatentypen
		// wichtiger Unterschied: die Variablen deklarieren nur Referenzen, keine
		// Instanzen
		Rechteck fussballFeld, basketballFeld;

		// die Objekte müssen erzeugt werden
		// hier die Werte für Länge und Breite bereits übergeben
		fussballFeld = new Rechteck(105, 68);
		basketballFeld = new Rechteck(28, 15);

		// Werte im 1. Objekt setzen 
		System.out.println("Fußballfeld: ");
		// fussballFeld.setzen(105, 68);
		fussballFeld.anzeigen();

		// werte im 2. Objekt setzen
		System.out.println("Basketballfeld: ");
		//basketballFeld.setzen(28, 15);
		basketballFeld.anzeigen();

		// weitere Fähigkeiten nützen (=Methoden aufrufen)
		int umfang = fussballFeld.berechneUmfang();
		int flaeche = fussballFeld.berechneFlaeche();
		double diagonale = fussballFeld.berechneDiagonale();
		System.out.printf("Fußballfeld: Umfang=%d, Fläche=%d, Diagonale=%.2f \n", 
				umfang, flaeche, diagonale);	


		umfang = basketballFeld.berechneUmfang();
		flaeche = basketballFeld.berechneFlaeche();
		diagonale = basketballFeld.berechneDiagonale();
		System.out.printf("Basketballfeld: Umfang=%d, Fläche=%d, Diagonale=%.2f \n", 
				umfang, flaeche, diagonale);	

	}

}
