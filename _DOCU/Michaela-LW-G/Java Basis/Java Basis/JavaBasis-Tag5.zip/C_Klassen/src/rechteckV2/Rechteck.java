package rechteckV2;

// Klasse (Schablone) für Rechtecke, die über eine Länge und Breite verfügen
// und Methoden zum Ermitteln von Umfang, Fläche,... dieses Rechtecks enthält 
public class Rechteck {
	// Attribute (Eigenschaften) der Objekte
	// private: nur die Klasse darf die Attribute lesen und verändern
	private int laenge, breite;
	
//	// Default-Konstruktor (=Konstruktor ohne Parameter)
//	// wird in dieser Klasse vom Compiler nicht hinzugefügt, 
//	// da wir einen eigenen Konstruktor definieren
//	public Rechteck() {
//		System.out.println("Konstruktor von Rechteck");
//	}
	
	// Konstruktor mit Werten für die Länge und Breite
	public Rechteck(int l, int b) {
		// die Werte übernehmen
		laenge = l;
		breite = b;
	}

	// setzen brauchen wir nur, wenn das Objekt nachträglich verändert werden soll 
	// public: die Methode darf von allen Klassen verwendet werden
	// nicht-static (muss man nicht kennzeichnen): die Methode gehört zu einem
	// Rechteck-Objekt
	public void setzen(int l, int b) {
		// die Werte aus den Parametern in die Attribute übernehmen
		laenge = l;
		breite = b;
	}

	// den Inhalt des Objekts anzeigen
	public void anzeigen() {
		System.out.printf("Rechteck: Länge=%d, Breite=%d\n", laenge, breite);
	}

	// Umfang berechnen (braucht keine Parameter für Länge und Breite)
	public int berechneUmfang() {
		int umfang = 2 * (laenge + breite);
		return umfang;
	}

	// Fläche berechnen
	public int berechneFlaeche() {
		int flaeche = laenge * breite;
		return flaeche;
	}

	// Diagonale berechnen
	public double berechneDiagonale() {
		double diagonale = Math.sqrt(laenge * laenge + breite * breite);
		return diagonale;
	}

}
