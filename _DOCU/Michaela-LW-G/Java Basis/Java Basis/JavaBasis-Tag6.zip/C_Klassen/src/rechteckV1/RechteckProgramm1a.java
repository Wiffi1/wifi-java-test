package rechteckV1;

import java.util.Scanner;

public class RechteckProgramm1a {

	public static void main(String[] args) {
		// Programm zur Berechnung von Fläche und Umfang eines Rechtecks
		// Variablen für Länge und Breite
		int laenge, breite;

		// Werte vom Benutzer einlesen:
		// Hilfsobjekt erzeugen, das vom Konsole-Inputstream liest
		Scanner input = new Scanner(System.in);

		// die Länge einlesen und in der vorgesehenen Variable eintragen (=Zuweisung)
		System.out.println("Gib bitte die Länge ein:");
		laenge = input.nextInt();

		// die Breite einlesen und in der vorgesehenen Variable eintragen (=Zuweisung)
		System.out.println("Gib bitte die Breite ein:");
		breite = input.nextInt();
		
		// Variable deklarieren und Objekt erzeugen
		Rechteck gartenRechteck = new Rechteck();
		
		// welche Werte enthält unser Rechteck zu Beginn?
		System.out.println("Werte vor dem Setzen:");
		gartenRechteck.anzeigen();
		
		
		// Werte setzen
		gartenRechteck.setzen(laenge, breite);
		System.out.println("Werte nach dem Setzen:");
		gartenRechteck.anzeigen();

		
		input.close();
	}

}
