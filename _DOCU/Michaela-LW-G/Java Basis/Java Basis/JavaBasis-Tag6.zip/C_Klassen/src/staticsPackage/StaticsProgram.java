package staticsPackage;

public class StaticsProgram {

	public static void main(String[] args) {
		System.out.println("Programmstart");
		CountClass.showCount();
		
		// Objekt der Klasse erzeugen
		CountClass objekt1 = new CountClass(5, "Tim");
		System.out.println("1. Objekt erzeugt");
		
		CountClass.showCount();
		objekt1.show();

		// Objekt der Klasse erzeugen
		CountClass objekt2 = new CountClass(7, "Susi");
		System.out.println("2. Objekt erzeugt");
		
		CountClass.showCount();
		objekt2.show();

		System.out.printf("Objekt 1: %s (Id=%d)\n", objekt1.getName(), objekt1.getId());
		System.out.printf("Objekt 2: %s (Id=%d)\n", objekt2.getName(), objekt2.getId());

		System.out.println("Vor Programmende");
		
		CountClass.showCount();
	}

}
