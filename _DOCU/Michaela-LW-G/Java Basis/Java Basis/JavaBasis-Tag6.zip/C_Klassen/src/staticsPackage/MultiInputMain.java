package staticsPackage;

import java.util.Scanner;

public class MultiInputMain {
	// ein allgemein verfügbares Objekt für den Bnutzerinput
	// Achtung: funktioniert nur, wenn input.nextLine() nicht verwendet wird
	final static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		inputTest1();
		inputTest2();

		// hier kann ich den input-Scanner schließen
		input.close();
	}

	static void inputTest1() {
		
		System.out.println("Gib bitte deinen Namen ein:");
		String name = input.next();
		System.out.println("Hallo, schönen Tag, " + name);

		
	}

	static void inputTest2() {
		// Scanner input = new Scanner(System.in);

		System.out.println("Gib bitte eine Zahl ein");
		int zahl = input.nextInt();
		if (zahl % 2 == 0) {
			System.out.println("Es ist eine gerade Zahl");
		} else {
			System.out.println("Es ist eine ungerade Zahl");
		}

		//input.close();
	}

}
