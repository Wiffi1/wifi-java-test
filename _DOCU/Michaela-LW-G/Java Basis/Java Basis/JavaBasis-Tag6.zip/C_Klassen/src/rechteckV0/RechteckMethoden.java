package rechteckV0;

public class RechteckMethoden {
	// Umfang berechnen
	public static int berechneUmfang(int laenge, int breite) {
		int umfang = 2 * (laenge + breite);
		return umfang;
	}

	// Fläche berechnen
	public static int berechneFlaeche(int laenge, int breite) {
		int flaeche = (laenge * breite);
		return flaeche;
	}
	
	// Diagonale berechnen
	public static double berechneDiagonale(int laenge, int breite) {
		double diagonale = Math.sqrt(laenge * laenge + breite * breite);
		return diagonale;
		
	}
}
