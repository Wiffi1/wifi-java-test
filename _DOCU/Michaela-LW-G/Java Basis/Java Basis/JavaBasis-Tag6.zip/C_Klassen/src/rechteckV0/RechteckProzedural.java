package rechteckV0;

import java.util.Scanner;

public class RechteckProzedural {

	public static void main(String[] args) {
		// Programm zur Berechnung von Fläche und Umfang eines Rechtecks
		// Variablen für Länge und Breite
		int laenge, breite;

		// Werte vom Benutzer einlesen:
		// Hilfsobjekt erzeugen, das vom Konsole-Inputstream liest
		Scanner input = new Scanner(System.in);

		// die Länge einlesen und in der vorgesehenen Variable eintragen (=Zuweisung)
		System.out.println("Gib bitte die Länge ein:");
		laenge = input.nextInt();

		// die Breite einlesen und in der vorgesehenen Variable eintragen (=Zuweisung)
		System.out.println("Gib bitte die Breite ein:");
		breite = input.nextInt();

		// Umfang etc. berechnen
		int umfang = RechteckMethoden.berechneUmfang(laenge, breite);
		int flaeche = RechteckMethoden.berechneFlaeche(laenge, breite);
		double diagonale = RechteckMethoden.berechneDiagonale(laenge, breite);
		
		System.out.printf("Umfang=%d, Fläche=%d, Diagonale=%.2f \n", umfang, flaeche, diagonale);	

		
		input.close();
	}

}
