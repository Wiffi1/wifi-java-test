package testPackage;

public class Hund {
	// Attribut "name"
	private String name /*= null*/;
	
	// Attribut "alter"
	private byte alter /*= 0*/;
	
	// Attribut für die Information ob der Hund geimpft ist
	// für alle Hunde am Anfang auf true setzen (Feldinitialisierung)
	private boolean geimpft = true;
	
//	// so einen Default-Konstruktor fügt der Compiler hinzu, wenn wir selber
//	// keinen Konstruktor schreiben
//	public Hund() {
//		
//	}
	
	// Konstruktor, der Name und Alter mit den Werten aus den Parametern 
	// initialisiert; geimpft bleibt auf true
	public Hund(String pName, byte pAlter) {
		System.out.println("Konstruktor von Hund (String, byte)");
		name = pName;
		alter = pAlter;
	}
	
	// Konstruktor, der Name, Alter und den Geimpft-Status
	// mit den Werten aus den Parametern initialisiert;
	public Hund(String pName, byte pAlter, boolean pGeimpft) {
		System.out.println("Konstruktor von Hund (String, byte, boolean)");
		name = pName;
		alter = pAlter;
		geimpft = pGeimpft;
	}
	
	public void anzeigen() {
		System.out.printf("Hund: Name=%s, Alter=%d, Geimpft=%b \n", name, alter, geimpft);
	}

}
