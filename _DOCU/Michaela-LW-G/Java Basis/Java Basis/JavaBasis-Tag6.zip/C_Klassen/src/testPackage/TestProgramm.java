package testPackage;

public class TestProgramm {

	public static void main(String[] args) {
		Hund struppi;
		byte alter = 5;
		struppi = new Hund("Struppi", alter);
		struppi.anzeigen();

		Hund strolchi;
		alter = 3;
		// den Konstruktor mit 3 Parametern verwenden
		strolchi = new Hund("Strolchi", alter, false);
		strolchi.anzeigen();

	}

}
