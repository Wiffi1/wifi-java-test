package staticsPackage2;

public class StaticsProgram {

	public static void main(String[] args) {
		
		// Objekt der Klasse erzeugen
		CountClass objekt1 = new CountClass("Tim");
		objekt1.show();

		// Objekt der Klasse erzeugen
		CountClass objekt2 = new CountClass("Susi");
		objekt2.show();

		System.out.printf("Objekt 1: %s (Id=%d)\n", objekt1.getName(), objekt1.getId());
		System.out.printf("Objekt 2: %s (Id=%d)\n", objekt2.getName(), objekt2.getId());


	}

}
