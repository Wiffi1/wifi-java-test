package staticsPackage2;

public class CountClass {

	// statisches Feld um die Anzahl der erzeugten Objekte zu zählen
	// gibt es für alle Objekte und die Klasse nur 1x
	private static int objectCount;

	// Instanz-Attribute (existieren 1x pro Instanz)
	// ID des Objekts
	private int id;
	// Name des Objekts
	private String name;

	// Konstruktor: wird im Zuge der Objekt-Erzeugung aufgerufen,
	// this verweist auf das Objekt, das gerade erzeugt wird
	public CountClass(String name) {
		this.name = name;
		// ID soll fortlaufend hochgezählt werden 
		// this.id = id;
		// Zugriff auf static Feld, um den Zähler zu erhöhen
		/*CountClass.*/objectCount ++;
		// die ID auf den aktuellen Zähler-Wert setzen
		this.id = objectCount;
	}

	// Instanzmethoden: werden mit einer Referenz aufgerufen,
	// eine Kopie dieser Referenz steht in this
	public int getId() {
		return /*this.*/id;
	}

	public String getName() {
		return /*this.*/name;
	}

	public void show() {
		System.out.printf("ID=%d, Name=%s \n", /*this.*/id, /*this.*/name);
	}
	

}
