package arrayPackage;

public class Temperaturen {

	public static void main(String[] args) {
		// Array für 12 double-Werte erzeugen
		double[] werte = new double[12];

		for (int i = 0; i < werte.length; i++) {
			// double wert = werte[i];
			System.out.printf("Anfangswert am Index %d: %.2f \n", i, werte[i]);
		}

		for (int i = 0; i < werte.length; i++) {
			// zufälligen Wert für jedes Monat ermitteln
			// random liefert einen Wert zwischen 0 und 0.9999999999
			double zufallsWert = Math.random();
			// ca Werte im Bereich von -20 bis +29
			// double temperatur = zufallsWert * 50 - 20;
			werte[i] = zufallsWert * 50 - 20;

		}

		System.out.println("Temperaturen (zufällig ermittelt):");

		for (int i = 0; i < werte.length; i++) {
			// die Temperatur des Monats anzeigen (dabei den Index auf eine Monatsnummer
			// umrechnen
			System.out.printf("Temperatur im Monat %d: %.2f \n", i + 1, werte[i]);
		}

		// Monat mit der niedrigsten und mit der höchsten Temperatur finden
		int iMin = 0, iMax = 0;

		for (int i = 1; i < werte.length; i++) {
			// wenn der aktuelle Wert kleiner ist als das bisherige Minimum
			if (werte[i] < werte[iMin]) {
				// den Index merken
				iMin = i;
			}

			// wenn der aktuelle Wert größer ist als das bisherige Maximum
			if (werte[i] > werte[iMax]) {
				// den Index merken
				iMax = i;
			}
		}

		System.out.printf("Das Minimum ist im Monat %d: %.2f \n", iMin + 1, werte[iMin]);
		System.out.printf("Das Maximum ist im Monat %d: %.2f \n", iMax + 1, werte[iMax]);
	}

}
