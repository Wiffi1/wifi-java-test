package hunde;

/*

Übung:
* toString() bei den restlichen abgeleiteten Klassen überschreiben
* Weitere Konstruktoren für die Initialisierung vorsehen wie beim Lawinenhund 
* Blindenhund um sinnvolle Attribute erweitern
* Weitere Spezialisierung erstellen. Z.B. Dackel (Schoßhund), Polizeihund, etc.


*/

public class HundeBeispiel {

	public static void main(String [] args) {
		System.out.println("** Hunde Bsp **");
		
		LawinenHund hund1 = new LawinenHund("Wuffi", 77,
				"Hochkar", 111);
		hund1.setAusbildungsgrad(3);
		hund1.setSchigebiet("Hochkar");
		hund1.setName("Wuffi");
		hund1.setChipId(7);
		System.out.println("law.steuer: " +
				hund1.berechneHundesteuer());
		
		System.out.println("law.hund: toString(): " + hund1.toString());
		System.out.println(hund1);
		
		Hund h2 = hund1;
		// welche methode wird ausgefuehrt? die vom hund oder lawinenhund???
		// Es wird die überschriebene Methode vom LawinenHund aufgerufen.
		// Late binding. Zur Laufzeit wird entschieden nicht zur Compilezeit.
		System.out.println("steuer: " + h2.berechneHundesteuer());
		
		System.out.println(hund1.getName() + " " +
				hund1.getSchigebiet());
		
		Hund rex = new Hund();
		// geht nur wenn attribut name public ist
		//rex.name = "Rex"; // geht nicht, da private
		rex.setName("Rex");
		rex.setChipId(7);
		System.out.println(rex.toString());
		
		System.out.println("steuer: " +
				rex.berechneHundesteuer());
		
		Blindenhund blind = new Blindenhund();
		
		
		Hund max;
		max = new Hund();
		max.setName("Maxi");
		max.setChipId(13);
		
		Hund snoopi = new Hund("Snoopi", 3);
				
		// nur der verweis der refernz wird kopiert
		// aber NICHT das object sondern nur die referenz!!!!
		Hund susi = rex;
		susi.setName("Susi");
		System.out.println(susi.getName());
		
		System.out.println("Der Name ist: " + rex.getName() +
				" , chip id: " + rex.getChipId());
		
		System.out.println(max.getName() + " " + max.getChipId());
		
	}
}
