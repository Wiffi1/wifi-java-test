package hunde;

public class Wachhund extends Hund {
	
	protected String einsatzort;

	public String getEinsatzort() {
		return einsatzort;
	}

	public void setEinsatzort(String einsatzort) {
		this.einsatzort = einsatzort;
	}

	@Override
	public double berechneHundesteuer() {
		return super.berechneHundesteuer() * 0.5;
	}
}
