package hunde;

// von der klasse von der geerbt wird,
// wird auch Basisklasse genannt.
// --> Die Klasse Hund ist die Basisklasse fuer
// die Klasse LawinenHund

public class LawinenHund extends Hund {

	private String schigebiet;
	private int ausbildungsgrad;
	
	public LawinenHund() {
		schigebiet = "Kitzbühel";
		ausbildungsgrad = 1;
	}
	
	public LawinenHund(String name, int chipId,
			String schigebiet, int ausbildungsgrad) {
		// ruft den konstruktor der basisklasse auf
		// basiert automatisch wenn nicht hingeschieben
		//super();
		super(name, chipId); // explizite angabe welcher konstruktor verwendet werden soll
		//this.name = name;
		//this.chipId = chipId;
		//setName(name);
		//setChipId(chipId);

		this.schigebiet = schigebiet;
		this.ausbildungsgrad = ausbildungsgrad;
	}
	
	public String getSchigebiet() {
		return schigebiet;
	}
	
	public void setSchigebiet(String schigebiet) {
		this.schigebiet = schigebiet;
	}
	
	public int getAusbildungsgrad() {
		return ausbildungsgrad;
	}
	
	public void setAusbildungsgrad(int ausbildungsgrad) {
		this.ausbildungsgrad = ausbildungsgrad;
	}
	
	// die Methode berechneHundesteuer()
	// wird ueberschieben!!!!
	// Achtung überschrieben und nicht überladen!
	// Mit der Annotation @Override gebe ich dem
	// Compiler zusätzlich den Hinweis das ich
	// überschreiben möchte.
	// Annotation @Override ist nicht notwendig
	// aber sinnvoll beim Überschreiben.
	@Override
	public double berechneHundesteuer() {
		// 1. Variante wäre die Konstante verwenden
		//return DEFAULT_STEUER * 0.75;
		
		// 2. Variante wäre die urspüngliche Methode
		// aufzurufen und dann mal 0.75 rechnen.
		// Mit super kann ich die ursprüngliche
		// (nicht überschriebene) methode aufrufen.
		return super.berechneHundesteuer() * 0.75;
	}
	
	@Override
	public String toString() {
//		return "name: " + name + ", chip id: " +
//				chipId + ", gebiet: " + schigebiet +
//				", gard: " + ausbildungsgrad;
		
		return super.toString() +
				", gebiet: " + schigebiet +
				", gard: " + ausbildungsgrad;
	}
}
