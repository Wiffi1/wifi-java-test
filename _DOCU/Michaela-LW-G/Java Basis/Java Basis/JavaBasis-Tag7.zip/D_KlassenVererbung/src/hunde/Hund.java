package hunde;

public class Hund {

	protected static final double DEFAULT_STEUER = 100.0;
	
	// name ist ein instanzattribut
	// --> existiert pro object/instanz
	protected String name;
	protected int chipId;
	
	// wenn ich mehrere konstruktoren deklariere
	// muessen sie unterscheidbar sein.
	// --> entweder unterschiedliche anzahl der parameter
	// --> oder falls gleich viele parameter
	//     dann unterschiedliche typen
	
	// default konstruktor
	public Hund() {
		name = "Nobody";
		chipId = -1; // -1 fuer unglueltige chip id
	}
	
	public Hund(String n, int id) {
		name = n;
		chipId = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String n) {
		name = n;
	}
	
	public int getChipId() {
		return chipId;
	}
	
	public void setChipId(int chipId) {
		this.chipId = chipId;
	}
	
	public double berechneHundesteuer() {
		return DEFAULT_STEUER;
	}
	
	@Override
	public String toString() {
		return "name: " + name + ", chip id: " +
				chipId;
	}
}
