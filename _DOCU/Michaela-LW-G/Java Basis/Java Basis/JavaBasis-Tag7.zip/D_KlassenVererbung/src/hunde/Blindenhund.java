package hunde;

public class Blindenhund extends Hund {

	 @Override
	 public double berechneHundesteuer() {
		 return 0.0;
	 }
}
