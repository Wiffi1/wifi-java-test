package arrayBsp;

public class ArrayExample {

	public static void main(String[] args) {


		double [] zahlen = new double [10];
		//double [] zahlen2 = new double [] {1, 2, 3};
		//double [] zahlen3 = {1, 2, 3};

		DoubleArrayHelper.zufaelligBefuellen(zahlen);
		
		// statische methode wird per Klassenname aufgerufen
		DoubleArrayHelper.arrayAusgabe(zahlen);
		
		DoubleArrayHelper.sortieren(zahlen);
		
		DoubleArrayHelper.arrayAusgabe(zahlen);
		
		// So würde es gehn, wenn es eine Instanzmethode und
		// keine statische Methode bzw. Klassenmethode wäre.
		//DoubleArrayHelper helper = new DoubleArrayHelper();
		//helper.arrayAusgabe(zahlen);
		// Statische Methoden sollten nicht per referenz aufgerufen werden,
		// auch wenn es prinzipiell erlaubt ist sondern per Klassenname.		
	}

}
