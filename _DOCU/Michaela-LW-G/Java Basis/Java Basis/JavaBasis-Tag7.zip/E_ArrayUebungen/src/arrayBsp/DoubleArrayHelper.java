package arrayBsp;

public class DoubleArrayHelper {

	/*
	weitere mögliche Funktionen:
	* minimum suchen
	* maximum suchen
	* durchschnitt ausrechen
	* bestimmten wert suchen mit toleranz. falls gefunden dann index returnieren. sonst -1 returnieren
	
	*/
	
	public static void arrayAusgabe(double [] werte) {
		System.out.println("*** Ausgabe des double arrays ***");
		for (double nr : werte) {
			System.out.println(nr);
		}
	}
	
	public static void zufaelligBefuellen(double [] werte) {
		for (int i = 0; i < werte.length; i++) {
			werte[i] = Math.random() * 10.0 + 20.0;
		}
	}
	
	public static void sortieren(double [] werte) {
		// implementierung eines minimum sort
		// startIndex ist der Startpunkt des unsortierten bereichs.
		for (int startIndex = 0; startIndex < werte.length; startIndex++) {
			int minimumIndex = startIndex;
			// durchlauf den unsortieren bereichs
			for (int i = startIndex + 1; i < werte.length; i++) {
				if (werte[i] < werte[minimumIndex]) {
					// --> neuen kleineren wert gefunden
					minimumIndex = i;
				}
			}
			// nun hat minimumIndex den index des kleinen werts vom unsortierten bereich
			
			// vertauschen der beiden werte
			double tmp = werte[startIndex];
			werte[startIndex] = werte[minimumIndex];
			werte[minimumIndex] = tmp;
		}
	}
}
