package datumPackage;

public class DatumMethoden {

	/**
	 * berechnet, ob ein Jahr ein Schaltjahr ist und liefert das Ergebnis zurück
	 * 
	 * @param jahr das Jahr, das getestet wird
	 * @return true wenn es ein Schaltjahr ist, sonst false
	 */
	public static boolean istSchaltjahr(int jahr) {
		boolean ergebnis = false;
		// TODO: Ergebnis korrekt berechnen
		return ergebnis;
	}


	/**
	 * liefert die Anzahl an Tagen eines Monats.
	 * 
	 * @param monat         das Monat für das die Anzahl ermittelt wird
	 * @param istSchaltjahr damit zeigt der Aufrufer an, ob es sich um ein Monat in
	 *                      einem Schaltjahr handelt
	 * @return die max. Anzahl an Tagen in dem Monat
	 */
	public static byte ermittleMaxTage(byte monat, boolean istSchaltjahr) {
		byte maxTage = 0;
		// TODO: Ergebnis korrekt berechnen
		return maxTage;
	}

	/**
	 * liefert die Anzahl an Tagen eines Monats in einem bestimmten Jahr. Es wird
	 * berücksichtigt, ob das Jahr ein Schaltjahr ist.
	 * 
	 * @param monat das Monat für das die Anzahl ermittelt wird
	 * @param jahr  das Jahr
	 * @return die max. Anzahl an Tagen in dem Monat
	 */
	public static byte ermittleMaxTage(byte monat, int jahr) {
		// feststellen, ob das Jahr ein Schaltjahr ist
		boolean schaltjahr = istSchaltjahr(jahr);
		// den anderen Overload aufrufen und die Max. Tage ermitteln
		byte maxTage = ermittleMaxTage(monat, schaltjahr);
		// das Ergebnis zurückliefern
		return maxTage;
	}

	// TODO: weitere Methode:
	// istGueltig: berechnet, ob ein Datum in Form von Tag, Monat und Jahr gültig
	// ist, und liefert das Ergebnis zurück

}
