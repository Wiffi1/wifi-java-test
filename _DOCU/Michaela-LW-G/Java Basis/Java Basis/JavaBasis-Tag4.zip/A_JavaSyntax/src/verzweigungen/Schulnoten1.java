package verzweigungen;

import java.util.Scanner;

public class Schulnoten1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Welche Note (1-5)");

		byte note = input.nextByte();
		// Variable für das Ergebnis
		String notenText;

		if (note == 1) {
			notenText = "Sehr gut";
		} else if (note == 2) {
			notenText = "Gut";
		} else if (note == 3) {
			notenText = "Befriedigend";
		} else if (note == 4) {
			notenText = "Genügend";
		} else if (note == 5) {
			notenText = "Nicht genügend";
		} else {
			notenText = "n.v.";
			System.err.println("Ungültige Note!");
		}
		
		// statt String-Verkettung
		// System.out.println("Die Note " + note + " entspricht '" + notenText + "'");

		// formatierte Ausgabe mit Platzhaltern
		// %d ... ganze Zahl
		// %s ... Zeichenfolge
		// %f ... Fließkommazahl
		// \n oder %n newline/zeilenumbruch
		System.out.printf("Die Note %d entspricht '%s'\n", note, notenText);
		input.close();
	}

}
