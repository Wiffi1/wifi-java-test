package schleifen;

import java.util.Scanner;

public class Ziffernsumme_3Stellen {

	public static void main(String[] args) {
		// Ziffernsumme für 3-stellige Zahl
		Scanner input = new Scanner(System.in);
		// Zahl vom Benutzer einlesen
		System.out.println("Gib bitte eine Zahl ein (3-stellig)");
		int zahl = input.nextInt();

		int ziffernsumme = 0;
		// Hilfsvariable für die letzte Ziffer
		int ziffer;

		// Einer-Stelle (letzte Stelle) berechnen mit Divisions-Rest
		ziffer = zahl % 10;
		// zur Summe dazuzählen
		ziffernsumme += ziffer;

		// für die 2. Stelle zuerst die Zahl durch 10 dividieren
		zahl /= 10; // statt zahl = zahl / 10;

		// jetzt können wir die 2. Stelle (=die neue Einer-Stelle) gleich wie vorher
		// behandeln
		// Einer-Stelle (letzte Stelle) berechnen mit Divisions-Rest
		ziffer = zahl % 10;
		// zur Summe dazuzählen
		ziffernsumme += ziffer;

		// für die 3. Stelle die Zahl wieder durch 10 dividieren
		zahl /= 10; // statt zahl = zahl / 10;
		
		
		
		// jetzt können wir die 3. Stelle (=die neue Einer-Stelle) gleich wie vorher
		// behandeln
		// Einer-Stelle (letzte Stelle) berechnen mit Divisions-Rest
		ziffer = zahl % 10;
		// zur Summe dazuzählen
		ziffernsumme += ziffer;
	
		// für eine weitere Stelle würden wir die Zahl wieder durch 10 dividieren
		zahl /= 10; // statt zahl = zahl / 10;

		
		System.out.println("Die Ziffernsumme beträgt " + ziffernsumme);

		input.close();

	}

}
