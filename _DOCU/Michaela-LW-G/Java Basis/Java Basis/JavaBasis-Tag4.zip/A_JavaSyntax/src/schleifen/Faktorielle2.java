package schleifen;

import java.util.Scanner;

public class Faktorielle2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		// Benutzerinput
		System.out.println("Faktorielle von welcher Zahl?");
		byte zahl = input.nextByte();

		// Ergebnisvariable
		double faktorielle = 1;

		// für alle Zahlen von der angegebenen Zahl bis 1
		for (byte i = zahl; i >= 1; i--) {

			// das bisherige Ergebnis mit i multiplizieren
			faktorielle *= i;
			
			// "Debug"- bzw. Trace-Ausgabe
			// printf statt println
			// %d ... Ganzzahl im Dezimalsystem
			// %f ... Fließkommazahl
			// %.2f ... Fließkommazahl mit 2 Nachkommastellen
			// \n oder %n ... newline/Zeilenumbruch 
			System.out.printf(" ... Faktorielle bei Faktor %d: %f \n", i, faktorielle);
			//System.out.println(" ... Faktorielle bei Faktor " + i + ": " + faktorielle );
		}

		System.out.println("Die Faktorielle von " + zahl + " ist " + faktorielle);
		
		input.close();

	}
	

}
