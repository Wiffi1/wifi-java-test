package schleifen;

import java.util.Scanner;

public class Faktorielle1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		// Benutzerinput
		System.out.println("Faktorielle von welcher Zahl?");
		byte zahl = input.nextByte();

		// Ergebnisvariable
		double faktorielle = 1;

		// für alle Zahlen von 1 bis zur angegebenen Zahl
		for (short i = 1; i <= zahl; i++) {

			// das bisherige Ergebnis mit i multiplizieren
			faktorielle *= i;
			// "Debug"- bzw. Trace-Ausgabe
			System.out.println(" ... Faktorielle bei Faktor " + i + ": " + faktorielle );
		}

		System.out.println("Die Faktorielle von " + zahl + " ist " + faktorielle);
		
		input.close();

	}
	

}
