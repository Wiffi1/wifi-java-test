package schleifen;

import java.util.Scanner;

public class Ziffernsumme {

	public static void main(String[] args) {
		// Ziffernsumme für 3-stellige Zahl
		Scanner input = new Scanner(System.in);
		// Zahl vom Benutzer einlesen
		System.out.println("Gib bitte eine Zahl ein");
		int zahl = input.nextInt();

		int ziffernsumme = 0;
		// Hilfsvariable für die letzte Ziffer
		int ziffer;
		
		// Ziffernsumme mit Schleife berechnen
		while (zahl != 0) {
			// Einer-Stelle (letzte Stelle) berechnen mit Divisions-Rest
			ziffer = zahl % 10;
			// zur Summe dazuzählen
			ziffernsumme += ziffer;

			// für die nächste Stelle die Zahl durch 10 dividieren
			zahl /= 10; // statt zahl = zahl / 10;

		}

		
		System.out.println("Die Ziffernsumme beträgt " + ziffernsumme);

		input.close();

	}

}
