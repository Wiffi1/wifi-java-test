package uebungen.schleifen;

import java.util.Scanner;

/*
 * Verwende den Euklid'schen Algorithmus zur Berechnung des größten gemeinsamen Teilers (GGT):
 * Man subtrahiere solange die kleinere der beiden Zahlen von der größeren, bis sie gleich sind.
*/
public class Ue1_EuklidGgt {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Zahl1:");
		int a = input.nextInt();

		System.out.println("Zahl2:");
		int b = input.nextInt();
		while (a != b) {

			if (a > b) {
				a -= b;
			} else {
				b -= a;
			}
			System.out.println("a=" + a + ", b=" + b);
		}

		System.out.println("Der GGT ist " + b);
		// oder auch
		// System.out.println("Der GGT ist " + a);

		input.close();
	}

}
