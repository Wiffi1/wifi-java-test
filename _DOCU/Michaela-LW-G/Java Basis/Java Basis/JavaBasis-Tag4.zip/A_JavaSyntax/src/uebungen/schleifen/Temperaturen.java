package uebungen.schleifen;

public class Temperaturen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
