package uebungen.schleifen;

import java.util.Scanner;

public class PrimzahlenA {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		// Zahl vom Benutzer einlesen
		System.out.println("Gib bitte eine Zahl ein");
		int zahl = input.nextInt();

		// Variable für die Information, ob wir einen Teiler gefunden haben
		// (bei Primzahlen bleibt der Wert bis zum Ende der Schleife false)
		boolean teilerGefunden = false;
	
		for (int i = 2; i < zahl; i++) {
			if (zahl % i == 0) {
				
				System.out.println(" ... Teiler gefunden: " + i);
				//System.out.println(zahl + " ist KEINE Primzahl");
				// für später merken, dass wir einen Teiler gefunden haben
				teilerGefunden = true;
				// die Schleife verlassen, weil das Ergebnis schon feststeht 
				break;
			}
			else {
				// hier können wir noch nicht feststellen, dass es eine Primzahl ist,
				// das nächste i könnte ja ein Teiler sein
			}
		}

		// wenn es eine Primzahl ist (wenn wir keinen Teiler gefunden haben)
		if (teilerGefunden == false) {
			// Ausgabe, für Primzahl
			System.out.println(zahl + " ist eine Primzahl");
		} else {
			// Ausgabe für "keine Primzahl"
			System.out.println(zahl + " ist KEINE Primzahl");
		}

		input.close();
	}

}
