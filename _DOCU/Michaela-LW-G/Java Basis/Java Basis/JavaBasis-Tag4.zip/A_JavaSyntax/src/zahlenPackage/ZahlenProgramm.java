package zahlenPackage;

import java.util.Scanner;

public class ZahlenProgramm {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		// Zahl vom Benutzer einlesen
		System.out.println("Gib bitte eine Zahl ein");
		int zahl1 = input.nextInt();
		System.out.println("Gib bitte noch eine Zahl ein");
		int zahl2 = input.nextInt();

		// Ziffernsumme berechnen, indem wir die Methode berechneZiffernsumme aufrufen
		int ziffernSumme1 = ZahlenMethoden.berechneZiffernsumme(zahl1);
		System.out.printf("Die Ziffernsumme von %d ist %d \n", zahl1, ziffernSumme1);

		// und für die 2. Zahl
		int ziffernSumme2 = ZahlenMethoden.berechneZiffernsumme(zahl2);
		System.out.printf("Die Ziffernsumme von %d ist %d \n", zahl2, ziffernSumme2);

		// GGT für die beiden Zahlen berechnen
		int ggt1 = ZahlenMethoden.berechneGGT(zahl1, zahl2);
		System.out.printf("Der größte gemeinsame Teiler von %d und %d ist %d \n", 
				zahl1, zahl2, ggt1);

		// Primzahl ja oder nein?
		boolean istPrim = ZahlenMethoden.istPrimzahl(zahl1);
		if (istPrim) {
			System.out.println(zahl1 + " ist eine Primzahl");
		} else {
			System.out.println(zahl1 + " ist keine Primzahl");
		}
		
		istPrim = ZahlenMethoden.istPrimzahl(ziffernSumme1);
		if (istPrim) {
			System.out.println(ziffernSumme1 + " ist eine Primzahl");
		} else {
			System.out.println(ziffernSumme1 + " ist keine Primzahl");
		}
		input.close();
	}

}
