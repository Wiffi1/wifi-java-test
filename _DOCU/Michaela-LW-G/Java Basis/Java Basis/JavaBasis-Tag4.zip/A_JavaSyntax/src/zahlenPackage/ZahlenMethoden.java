package zahlenPackage;

// Hilfsklasse die verschiedene nützliche Methoden für ganze Zahlen enthält
public class ZahlenMethoden {
	// Methode, die die Ziffernsumme einer Zahl berechnet und zurückliefert
	// Name der Methode: berechneZiffernsumme
	// Parameter: int zahl: die Zahl, von der die Ziffernsumme berechnet wird
	// Returntyp: int (die ermittelte Ziffernsumme)
	// public: die Methode darf von überall aus aufgerufen werden
	// static: die Methode darf ohne Objekt aufgerufen werden
	public static int berechneZiffernsumme(int zahl) {
		int ziffernsumme = 0;
		// Hilfsvariable für die letzte Ziffer
		int ziffer;

		// Ziffernsumme mit Schleife berechnen
		while (zahl != 0) {
			// Einer-Stelle (letzte Stelle) berechnen mit Divisions-Rest
			ziffer = zahl % 10;
			// zur Summe dazuzählen
			ziffernsumme += ziffer;

			// für die nächste Stelle die Zahl durch 10 dividieren
			zahl /= 10; // statt zahl = zahl / 10;

		}
		// das Ergebnis zurückliefern
		return ziffernsumme;
	}

	// Methode, die den GGT von zwei Zahlen berechnet und zurückliefert
	public static int berechneGGT(int a, int b) {
		while (a != b) {

			if (a > b) {
				a -= b;
			} else {
				b -= a;
			}
			System.out.println("a=" + a + ", b=" + b);
		}
		// den Teiler zurückliefern
		return a;
	}

	// Methode, die ermittelt, ob eine Zahl eine Primzahl ist oder nicht
	public static boolean istPrimzahl(int zahl) {

		for (int i = 2; i < zahl; i++) {
			if (zahl % i == 0) {

				System.out.println(" ... Teiler gefunden: " + i);

				// jetzt wissen wir, dass es keine Primzahl ist -> false zurückliefern
				return false;
			} else {
				// hier können wir noch nicht feststellen, dass es eine Primzahl ist,
				// das nächste i könnte ja ein Teiler sein
			}
		}
		// wenn wir hierherkommen, haben wir keinen Teiler gefunden -> es ist eine
		// Primzahl
		return true;
	}

}
